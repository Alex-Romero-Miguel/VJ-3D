using System;

public interface ITileConfigurable
{
    void Configure(int variant, string extra);
}