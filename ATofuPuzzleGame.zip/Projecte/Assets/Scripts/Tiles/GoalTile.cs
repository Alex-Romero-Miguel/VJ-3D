using UnityEngine;
using System.Collections;

public class GoalTile : TileBase
{
    private LevelManager levelManager;

    private void Start()
    {
        levelManager = LevelManager.Instance;
    }

    protected override void Activate(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            MoveCube cube = other.GetComponentInParent<MoveCube>();

            if (cube != null && cube.isStanding() && !cube.isDivided())
            {
                //Debug.Log("VICTORIA");
                levelManager.CompleteLevel();
            }
            //else
            //{
            //    Debug.Log("Estás en la meta, pero TUMBADO. ¡Ponte de pie!");
            //}
        }
    }

    public override void Reset() {}
}