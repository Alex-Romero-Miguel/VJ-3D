using UnityEngine;
using System.Collections.Generic;

public class BridgeButton : TileBase, ITileConfigurable
{
    // Marca esto como TRUE solo en el prefab del botón Cruz (Strict)
    public bool isStrictButton;

    public int channelID; // Asignado por MapCreator
    private List<BridgeTile> connectedBridges = new List<BridgeTile>();

    // Esta función la llama MapCreator al crear el mapa
    public void Configure(int id, string extra)
    {
        this.channelID = id;
    }

    private void Start()
    {
        BridgeTile[] allBridges = FindObjectsByType<BridgeTile>(FindObjectsInactive.Include, FindObjectsSortMode.None);

        foreach (BridgeTile bridge in allBridges)
        {
            if (bridge.channelID == this.channelID)
            {
                connectedBridges.Add(bridge);

            }
        }
        //Debug.Log($"Botón ID {channelID} encontró {connectedBridges.Count} puentes.");
    }

    protected override void Activate(Collider other)
    {
        MoveCube player = other.GetComponentInParent<MoveCube>();
        if (player == null) return;

        if (isStrictButton) // Botón Cruz
        {
            if (player.isStanding() && !player.isDivided())
                PressButton();
        }
        else // Boton Rodondo
        {
            PressButton();
        }
    }

    public override void Reset()
    {
        foreach (BridgeTile bridge in connectedBridges)
        {
            if (bridge != null)
            {
                bridge.Reset();
                //Debug.Log("reset");
            }
        }
    }

    private void PressButton()
    {
        // Activar todos los puentes conectados
        foreach (BridgeTile bridge in connectedBridges)
        {
            if (bridge != null)
            {
                bridge.ToggleState();
                //Debug.Log("activate");
            }
        }
    }

    // Dibuja una línea en el editor para ver a qué puentes está conectado
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        foreach (var bridge in connectedBridges)
        {
            if (bridge != null)
                Gizmos.DrawLine(transform.position, bridge.transform.position);
        }
    }
}